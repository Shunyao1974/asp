﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace prjAspDemo.DataAccess
{
    public partial class WfrmViewDemo : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            lblMessage.Visible = false;
        }

        protected void FormView1_ItemInserted(object sender, FormViewInsertedEventArgs e)
        {
            
                Response.Redirect("WfrmCustomerList1.aspx");
                
            
        }

        protected void FormView1_ItemInserting(object sender, FormViewInsertEventArgs e)
        {
            if (string.IsNullOrEmpty(e.Values["fName"].ToString()))
            {
                lblMessage.Visible = true;
                lblMessage.Text = "姓名是必填欄位";
                e.Cancel = true;
            }
        }
    }
}