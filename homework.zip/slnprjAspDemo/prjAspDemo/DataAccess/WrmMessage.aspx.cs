﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace prjAspDemo.DataAccess
{
    public partial class WrmMessage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            lblMessage.Visible = false;
        }

        protected void fMessageTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        protected void FormView1_ItemInserting(object sender, FormViewInsertEventArgs e)
        {
            string message = e.Values["fMessage"].ToString();
            if (string.IsNullOrEmpty(message))
            {
                lblMessage.Visible = true;
                lblMessage.Text = "留言必須填寫";
                e.Cancel = true;
                return;
            }
            if (message.Length < 15)
            {
                lblMessage.Visible = true;
                lblMessage.Text = "留言必須至少15個字";
                e.Cancel = true;
                return;
            }
            e.Values["fDate"] = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
        }
    }
}