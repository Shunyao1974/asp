﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace prjAspDemo.DataAccess
{
    public partial class WfrmShopping_AddtoCart : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string id = Request.QueryString["pid"];
            if (string.IsNullOrEmpty(id))
                Response.Redirect("WfrmShopping.aspx");           
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string id = Request.QueryString["pid"];
            SqlDataSource sds = new SqlDataSource();
            sds.ConnectionString = @"Data Source=.;Initial Catalog=dbDemo;Integrated Security=True";
            //sds.SelectCommand = "SELECT *FROM tCustomer WHERE fName LIKE '%"+txtKeyword.Text+"%'";
            sds.SelectCommand = "SELECT *FROM tProduct WHERE fId=@KK";
            sds.SelectParameters.Add("KK",id);
            DataView dv = sds.Select(DataSourceSelectArguments.Empty) as DataView;

            if (dv.Table.Rows.Count <= 0)
            {
                Response.Redirect("WfrmShopping.aspx");
            }


            string sql = "INSERT INTO tShoppingCart(";
            sql += "fDate,";
            sql += "fCustomer,";
            sql += "fProduct,";
            sql += "fCount,";
            sql += "fPrice ";
            sql += " )VALUES(";
            sql += "'" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "',";
            sql += "'Marco',";
            sql += "'" + dv[0]["fName"].ToString() + "',";
            sql += "" + TextBox1.Text + ",";
            sql += "" + dv[0]["fPrice"].ToString() + ")";
            sds.InsertCommand = sql;
            sds.Insert();

            Response.Redirect("WfrmShopping.aspx");
        }

    }
}