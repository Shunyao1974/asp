﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace prjAspDemo.DataAccess
{
    public partial class WfrmDataSouceDemo : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            lblMessage.Visible = false;
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            SqlDataSource sds = new SqlDataSource();
            sds.ConnectionString = @"Data Source=.;Initial Catalog=dbDemo;Integrated Security=True";
            sds.InsertCommand = getInsertSql();
            sds.Insert();

            lblMessage.Visible = true;
            lblMessage.Text = "新增資料成功";
        }

        private string getInsertSql()
        {
            string sql = "INSERT INTO tCustomer(";
            sql += " fName, ";
            sql += " fPhone, ";
            sql += " fEmail, ";
            sql += " fAddress ";
            sql += " )VALUES( ";
            sql += " '" + txtName.Text + "', ";
            sql += " '" + txtPhone.Text + "', ";
            sql += " '" + txtEmail.Text + "', ";
            sql += " '" + txtAddress.Text + "') ";

            return sql;
        }

        protected void Button4_Click(object sender, EventArgs e)
        {
            SqlDataSource sds = new SqlDataSource();
            sds.ConnectionString = @"Data Source=.;Initial Catalog=dbDemo;Integrated Security=True";
            sds.SelectCommand = "SELECT *FROM tCustomer";
            GridView1.DataSource = sds.Select(DataSourceSelectArguments.Empty);
            GridView1.DataBind();
        }

        protected void Button5_Click(object sender, EventArgs e)
        {
            SqlDataSource sds = new SqlDataSource();
            sds.ConnectionString = @"Data Source=.;Initial Catalog=dbDemo;Integrated Security=True";
            //sds.SelectCommand = "SELECT *FROM tCustomer WHERE fName LIKE '%"+txtKeyword.Text+"%'";
            sds.SelectCommand = "SELECT *FROM tCustomer WHERE fName LIKE @KK";
            sds.SelectParameters.Add("KK", "%" + txtKeyword.Text + "%");
            DataView dv = sds.Select(DataSourceSelectArguments.Empty) as DataView;

            if (dv.Table.Rows.Count <= 0)
            {
                lblMessage.Visible = true;
                lblMessage.Text = "查無資料";
                return;
            }

            txtId.Text = dv.Table.Rows[0]["fId"].ToString();
            txtName.Text = dv.Table.Rows[0]["fName"].ToString();
            txtPhone.Text = dv.Table.Rows[0]["fPhone"].ToString();
            txtEmail.Text = dv.Table.Rows[0]["fEmail"].ToString();
            txtAddress.Text = dv.Table.Rows[0]["fAddress"].ToString();
        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtId.Text = GridView1.SelectedRow.Cells[1].Text;
            txtName.Text = GridView1.SelectedRow.Cells[2].Text;
            txtPhone.Text = GridView1.SelectedRow.Cells[3].Text;
            txtEmail.Text = GridView1.SelectedRow.Cells[4].Text;
            txtAddress.Text = GridView1.SelectedRow.Cells[5].Text;
        }
    }
}